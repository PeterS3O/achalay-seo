# Señales de rendimiento en Google News

## Cómo usar esta referencia

Este documento resume criterios editoriales de trabajo para interpretar oportunidades de Google News. No contiene datos privados, métricas internas ni resultados de Search Console.

Trata cada recomendación como una hipótesis editorial que debe revisarse posteriormente con los datos disponibles del medio. No hay garantía de tráfico ni de aparición en Google News o Top Stories.

## Como aplicar la senal

Clasifica cada candidato antes de recomendarlo:

| Tipo | Condicion | Tratamiento en la pauta |
|---|---|---|
| `NOTICIA ACCIONABLE` | Hecho actual verificable, entidad o evento concreto e impacto claro en alimentos y bebidas. | Puede ser `PUBLICAR AHORA` si hay evidencia suficiente. |
| `ÁNGULO TÉCNICO REACTIVO` | Un hecho actual permite explicar implicancias de formulación, inocuidad, regulación, packaging u operaciones. | Recomendar con un titular anclado en el hecho, no sólo en la tecnología. |
| `AUTORIDAD / EVERGREEN` | Tema útil pero sin disparador actual comprobable. | No tratar como oportunidad fuerte de Google News; proponerlo sólo como actualización o contenido de autoridad si aporta valor. |

Una oportunidad fuerte no necesita que varias fuentes repitan el mismo comunicado, pero sí debe pasar estos tres filtros:

1. **Actualidad:** publicado o actualizado dentro del rango solicitado, o con una novedad material verificable.
2. **Hecho:** fuente primaria, regulador, empresa, alerta o cobertura editorial confiable que sostenga el acontecimiento.
3. **Traducción industrial:** una respuesta concreta para formulación, calidad, inocuidad, regulación, compras, operaciones, packaging o decisión de negocio en México.

Al formular el titular sugerido, nombra el hecho o la entidad cuando ayude a explicar por qué ocurre ahora, y completa con la implicancia industrial. Evita titulares genéricos del tipo “las tendencias de...” si el valor real es un caso, medida o alerta puntual.

## Verificacion y aprendizaje

- Google News es obligatorio como universo de descubrimiento, pero Top Stories es una señal adicional, no una garantía de clics.
- Registra las URLs publicadas desde estas recomendaciones y revísalas con los datos disponibles cuando el volumen permita leer tendencias.
- La atribución de demanda requiere evidencia independiente; no la deduzcas de una simple coincidencia de cobertura.
- Si se detectan variantes de URL que fragmentan la medición, registra el hallazgo y recomienda validar canonical, redirección y sitemap con el equipo técnico.

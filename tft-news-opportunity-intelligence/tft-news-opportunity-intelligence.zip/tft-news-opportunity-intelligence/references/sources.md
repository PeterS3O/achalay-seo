# Fuentes principales

Consulta este universo para cada ejecucion. Puedes usar feeds RSS equivalentes. Las 24 rutas de Google News son obligatorias. Si agregas una fuente editorial util que no figure aqui, etiquetala como **complementaria** y mantenla separada del conteo principal.

## Google News — Mexico

### Industria e innovacion alimentaria

1. [industria de alimentos](https://news.google.com/search?q=industria%20de%20alimentos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
2. [alimentos y bebidas](https://news.google.com/search?q=alimentos%20y%20bebidas&hl=es-419&gl=MX&ceid=MX%3Aes-419)
3. [innovacion alimentaria](https://news.google.com/search?q=innovaci%C3%B3n%20alimentaria&hl=es-419&gl=MX&ceid=MX%3Aes-419)
4. [ingredientes alimentarios](https://news.google.com/search?q=ingredientes%20alimentarios&hl=es-419&gl=MX&ceid=MX%3Aes-419)
5. [reformulacion de alimentos](https://news.google.com/search?q=reformulaci%C3%B3n%20de%20alimentos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
6. [alimentos funcionales](https://news.google.com/search?q=alimentos%20funcionales&hl=es-419&gl=MX&ceid=MX%3Aes-419)

### Categorias de producto

7. [bebidas](https://news.google.com/search?q=bebidas&hl=es-419&gl=MX&ceid=MX%3Aes-419)
8. [lacteos](https://news.google.com/search?q=l%C3%A1cteos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
9. [panificacion](https://news.google.com/search?q=panificaci%C3%B3n&hl=es-419&gl=MX&ceid=MX%3Aes-419)
10. [snacks](https://news.google.com/search?q=snacks&hl=es-419&gl=MX&ceid=MX%3Aes-419)
11. [industria carnica](https://news.google.com/search?q=industria%20c%C3%A1rnica&hl=es-419&gl=MX&ceid=MX%3Aes-419)
12. [alimentos plant based](https://news.google.com/search?q=alimentos%20plant%20based&hl=es-419&gl=MX&ceid=MX%3Aes-419)
13. [suplementos alimenticios](https://news.google.com/search?q=suplementos%20alimenticios&hl=es-419&gl=MX&ceid=MX%3Aes-419)

### Inocuidad y regulacion

14. [inocuidad alimentaria](https://news.google.com/search?q=inocuidad%20alimentaria&hl=es-419&gl=MX&ceid=MX%3Aes-419)
15. [COFEPRIS alimentos](https://news.google.com/search?q=COFEPRIS%20alimentos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
16. [etiquetado de alimentos](https://news.google.com/search?q=etiquetado%20de%20alimentos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
17. [NOM alimentos](https://news.google.com/search?q=NOM%20alimentos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
18. [alerta sanitaria alimentos](https://news.google.com/search?q=alerta%20sanitaria%20alimentos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
19. [retiro de alimentos](https://news.google.com/search?q=retiro%20de%20alimentos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
20. [contaminacion alimentaria](https://news.google.com/search?q=contaminaci%C3%B3n%20alimentaria&hl=es-419&gl=MX&ceid=MX%3Aes-419)

### Packaging y operaciones

21. [packaging de alimentos](https://news.google.com/search?q=packaging%20de%20alimentos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
22. [envases sostenibles](https://news.google.com/search?q=envases%20sostenibles&hl=es-419&gl=MX&ceid=MX%3Aes-419)
23. [procesamiento de alimentos](https://news.google.com/search?q=procesamiento%20de%20alimentos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
24. [tendencias de consumo alimentos](https://news.google.com/search?q=tendencias%20de%20consumo%20alimentos&hl=es-419&gl=MX&ceid=MX%3Aes-419)

## Medios especializados

25. [The Food Tech](https://thefoodtech.com/)
26. [Alfa Editores Tecnicos](https://www.alfa-editores.com.mx/)
27. [Industria Alimenticia](https://www.industriaalimenticia.com/)
28. [Food News Latam](https://www.foodnewslatam.com/)
29. [FoodNavigator](https://www.foodnavigator.com/)
30. [Food Business News](https://www.foodbusinessnews.net/)

Usa TFT para estudiar estilo y detectar cobertura previa. No lo cuentes como competidor, medio independiente ni respaldo externo.

## Grandes diarios y medios de negocios

31. [El Economista — Empresas](https://www.eleconomista.com.mx/empresas)
32. [El Financiero — Empresas](https://www.elfinanciero.com.mx/empresas/)
33. [Expansion — Empresas](https://expansion.mx/empresas)
34. [Forbes Mexico — Negocios](https://forbes.com.mx/negocios/)
35. [El Universal — Cartera](https://www.eluniversal.com.mx/cartera/)
36. [Reuters — Business](https://www.reuters.com/business/)

## Fuentes oficiales de validacion

Usalas cuando el acontecimiento lo requiera para verificar cifras, normativa, alertas sanitarias, comercio exterior o comunicados. No las cuentes como medios editoriales independientes ni las sustituyas por una nota de prensa en el resultado.

- [Diario Oficial de la Federacion](https://www.dof.gob.mx/) — NOM, decretos y regulacion.
- [COFEPRIS — alertas sanitarias de alimentos](https://www.gob.mx/cofepris/documentos/alertas-sanitarias-de-alimentos?state=published) — riesgos y retiros relevantes en Mexico.
- [Red de Alerta Rapida](https://www.alertas.gob.mx/) — alertas de alimentos, productos y servicios.
- [SENASICA](https://www.gob.mx/senasica/es) — sanidad, inocuidad y comercio agroalimentario.
- [PROFECO](https://www.gob.mx/profeco) — etiquetado, estudios de calidad y proteccion al consumidor.
- [Secretaria de Economia](https://www.gob.mx/se) y [VUCEM](https://www.ventanillaunica.gob.mx/) — comercio exterior, regulacion e importaciones.
- [INEGI](https://www.inegi.org.mx/) y [SIAP](https://www.gob.mx/siap) — produccion, precios y estadisticas relevantes.
- [FDA — Recalls, Market Withdrawals, & Safety Alerts](https://www.fda.gov/safety/recalls-market-withdrawals-safety-alerts) y [USDA FSIS recalls](https://www.fsis.usda.gov/recalls) — cuando una alerta de Estados Unidos afecte exportaciones o abastecimiento mexicano.
- Sala de prensa, relacion con inversionistas o comunicado oficial de la empresa u organismo directamente involucrado.

## Ventana temporal

- Prioridad maxima: publicaciones de las ultimas 6 horas.
- Prioridad siguiente: 6 a 24 horas.
- Considera 24 a 48 horas solo si hay novedades sustanciales o cobertura adicional reciente.
- Descarta acontecimientos antiguos republicados sin informacion nueva.

## Secciones y audiencia de TFT

Revisa cuando esten disponibles: Soluciones y tecnologia alimentaria; Bebidas; Lacteos y derivados; Panificacion y snacks; Carnicos y alternativas plant-based; Confiteria; Suplementos alimenticios; Metodos de control y regulaciones; Seguridad e inocuidad alimentaria; Normatividad y regulaciones; Packaging y procesamiento; Materiales; Diseño e innovacion; Envasado y procesamiento.

La audiencia prioritaria son profesionales de alimentos y bebidas: I+D, formulacion, calidad e inocuidad, asuntos regulatorios, compras, operaciones y planta, packaging, sostenibilidad, directivos y tomadores de decisiones empresariales.

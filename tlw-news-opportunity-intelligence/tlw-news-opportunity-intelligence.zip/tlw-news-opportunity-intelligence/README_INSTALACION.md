# Instalar TLW News Opportunity Intelligence

Este paquete debe conservar su estructura completa: `SKILL.md`, `references/` y `agents/`.

## Instalación en Codex Desktop

1. Descomprime el archivo `.zip`.
2. Copia la carpeta `tlw-news-opportunity-intelligence` completa dentro de la carpeta de skills de Codex:
   - macOS/Linux: `~/.codex/skills/`
   - Windows: `%USERPROFILE%\.codex\skills\`
3. Reinicia Codex o abre una conversación nueva.
4. Ejecútala con:

```text
$tlw-news-opportunity-intelligence busca las oportunidades de hoy
```

Por defecto analiza las últimas 24 horas. Se puede indicar otro período en el pedido.

No copies solamente `SKILL.md`: las referencias incluidas son parte necesaria del funcionamiento.

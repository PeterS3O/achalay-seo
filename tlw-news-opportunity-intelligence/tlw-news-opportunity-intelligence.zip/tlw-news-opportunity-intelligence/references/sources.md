# Fuentes principales

Consulta este universo para cada ejecucion. Puedes usar feeds RSS equivalentes. Las 24 rutas de Google News son obligatorias. Si agregas una fuente editorial util que no figure aqui, etiquetala como **complementaria** y mantenla separada del conteo principal.

## Google News — Mexico

### Logistica y cadena de suministro

1. [logistica](https://news.google.com/search?q=log%C3%ADstica&hl=es-419&gl=MX&ceid=MX%3Aes-419)
2. [shipping](https://news.google.com/search?q=shipping&hl=es-419&gl=MX&ceid=MX%3Aes-419)
3. [cadena de suministro](https://news.google.com/search?q=cadena%20de%20suministro&hl=es-419&gl=MX&ceid=MX%3Aes-419)
4. [centro de distribucion](https://news.google.com/search?q=centro%20de%20distribuci%C3%B3n&hl=es-419&gl=MX&ceid=MX%3Aes-419)
5. [almacenes logisticos](https://news.google.com/search?q=almacenes%20log%C3%ADsticos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
6. [inversiones logisticas](https://news.google.com/search?q=inversiones%20log%C3%ADsticas&hl=es-419&gl=MX&ceid=MX%3Aes-419)

### Transporte e infraestructura

7. [transporte de carga](https://news.google.com/search?q=transporte%20de%20carga&hl=es-419&gl=MX&ceid=MX%3Aes-419)
8. [autotransporte](https://news.google.com/search?q=autotransporte&hl=es-419&gl=MX&ceid=MX%3Aes-419)
9. [puertos](https://news.google.com/search?q=puertos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
10. [transporte maritimo](https://news.google.com/search?q=transporte%20mar%C3%ADtimo&hl=es-419&gl=MX&ceid=MX%3Aes-419)
11. [ferrocarril de carga](https://news.google.com/search?q=ferrocarril%20de%20carga&hl=es-419&gl=MX&ceid=MX%3Aes-419)
12. [ultima milla](https://news.google.com/search?q=%C3%BAltima%20milla&hl=es-419&gl=MX&ceid=MX%3Aes-419)
13. [paqueteria](https://news.google.com/search?q=paqueter%C3%ADa&hl=es-419&gl=MX&ceid=MX%3Aes-419)

### Comercio exterior

14. [aduana](https://news.google.com/search?q=aduana&hl=es-419&gl=MX&ceid=MX%3Aes-419)
15. [comercio exterior](https://news.google.com/search?q=comercio%20exterior&hl=es-419&gl=MX&ceid=MX%3Aes-419)
16. [aranceles](https://news.google.com/search?q=aranceles&hl=es-419&gl=MX&ceid=MX%3Aes-419)
17. [nearshoring](https://news.google.com/search?q=nearshoring&hl=es-419&gl=MX&ceid=MX%3Aes-419)
18. [T-MEC](https://news.google.com/search?q=T-MEC&hl=es-419&gl=MX&ceid=MX%3Aes-419)

### Acontecimientos y disrupciones

19. [bloqueos carreteros](https://news.google.com/search?q=bloqueos%20carreteros&hl=es-419&gl=MX&ceid=MX%3Aes-419)
20. [huelga transportistas](https://news.google.com/search?q=huelga%20transportistas&hl=es-419&gl=MX&ceid=MX%3Aes-419)
21. [cierre de puertos](https://news.google.com/search?q=cierre%20de%20puertos&hl=es-419&gl=MX&ceid=MX%3Aes-419)
22. [retrasos aduanas](https://news.google.com/search?q=retrasos%20aduanas&hl=es-419&gl=MX&ceid=MX%3Aes-419)
23. [crisis de suministro](https://news.google.com/search?q=crisis%20de%20suministro&hl=es-419&gl=MX&ceid=MX%3Aes-419)

### Tema adicional

24. [Tema de Google News](https://news.google.com/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNR3M1YzNnU0JtVnpMVFF4T1NnQVAB?hl=es-419&gl=MX&ceid=MX%3Aes-419)

## Medios especializados

25. [T21](https://t21.com.mx/)
26. [The Logistics World — Logistica y distribucion](https://thelogisticsworld.com/logistica-y-distribucion/)
27. [TyT](https://www.tyt.com.mx/)
28. [Info-Transportes](https://www.info-transportes.com.mx/)
29. [Enfasis Logistica](https://logistica.enfasis.com/)

Usa TLW para estudiar estilo y detectar cobertura previa. No lo cuentes como competidor, medio independiente ni respaldo externo.

## Grandes diarios y medios de negocios

30. [El Economista — Empresas](https://www.eleconomista.com.mx/empresas)
31. [El Economista — Tecnologia](https://www.eleconomista.com.mx/tecnologia)
32. [El Financiero — Empresas](https://www.elfinanciero.com.mx/empresas/)
33. [El Financiero — Tech](https://www.elfinanciero.com.mx/tech/)
34. [Expansion — Logistica, cadenas de suministro y transporte](https://expansion.mx/empresas-logistica-cadenas-de-suministro-transporte)
35. [Expansion — Tecnologia](https://expansion.mx/tecnologia)
36. [Forbes Mexico — Ultimas noticias](https://forbes.com.mx/ultimas-noticias/)
37. [Expansion — Empresas](https://expansion.mx/empresas)
38. [El Financiero — Economia](https://www.elfinanciero.com.mx/economia/)
39. [El Universal — Cartera](https://www.eluniversal.com.mx/cartera/)
40. [El Economista — Ultimas noticias](https://www.eleconomista.com.mx/ultimas-noticias)

## Fuentes oficiales de validacion

Usalas cuando el acontecimiento lo requiera para verificar cifras, normativa, estado operativo o comunicados. No las cuentes como medios editoriales independientes ni las sustituyas por una nota de prensa en el resultado.

- [Diario Oficial de la Federacion](https://www.dof.gob.mx/) — decretos, aranceles y regulacion.
- [ANAM](https://www.anam.gob.mx/) y [SAT](https://www.sat.gob.mx/) — aduanas y comercio exterior.
- [Estado operacional de puertos — SEMAR](https://meteorologia.semar.gob.mx/puertos/) — aperturas y cierres vigentes.
- [SICT / DGAF — estadistica de autotransporte federal](https://micrs.sct.gob.mx/transporte-y-medicina-preventiva/autotransporte-federal/estadistica/) — flota, permisos y autotransporte.
- [Secretaria de Economia](https://www.gob.mx/se), [STPS](https://www.gob.mx/stps) y [CFCRL](https://www.gob.mx/cfcrl) — comercio, inversiones y conflictos laborales.
- [INEGI](https://www.inegi.org.mx/) — comercio, transporte y actividad economica.
- [CAPUFE](https://www.gob.mx/capufe) y comunicados institucionales de SICT — afectaciones en carreteras federales.
- Sala de prensa, relacion con inversionistas o comunicado oficial de la empresa u organismo directamente involucrado.

## Ventana temporal

- Prioridad maxima: publicaciones de las ultimas 6 horas.
- Prioridad siguiente: 6 a 24 horas.
- Considera 24 a 48 horas solo si hay novedades sustanciales o cobertura adicional reciente.
- Descarta acontecimientos antiguos republicados sin informacion nueva.

## Secciones y audiencia de TLW

Revisa cuando esten disponibles: Actualidad logistica; Logistica y distribucion; Transporte; Comercio internacional; Almacenes e inventarios; Abastecimiento y compras; Innovacion; Tecnologia; Logistica en comercio electronico; Manufactura y planeacion estrategica.

La audiencia prioritaria son profesionales de logistica y supply chain, directivos de operaciones, responsables de transporte, importadores, exportadores y tomadores de decisiones empresariales.
